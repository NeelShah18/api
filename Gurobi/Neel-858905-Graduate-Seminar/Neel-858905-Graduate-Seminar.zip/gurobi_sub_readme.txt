By: Neel Shah - 858905
Guided By: Dr. S. Choudhary
Subjetc: Graduae Seminar

Gurobi readme:

Step-1: Install Gurobi with Acadmic licence with anaconda python(Ubuntu-Because anaconda will become your default python and you can use Gurobi as library offline).

Step-2: Run code with number of node in the network:
        Example: python gurobi_test 10
        #Here 10 is number of node in the network

Step-3: It will give optimal path.
        Output: Optimal tour: [0, 3, 9, 4, 5, 6, 1, 2, 8, 7]

Step-4: It also have other details, which optimize method it is using, time taken by the alorithm and many other.
        Example:Optimize a model with 10 rows, 55 columns and 100 nonzeros
        Optimize a model with 10 rows, 55 columns and 100 nonzeros
        etc...

#Screenshot is attached in folder how to run it.